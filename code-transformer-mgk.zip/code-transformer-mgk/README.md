# transformer-mgk code submission
Instructions for running the experiments in our paper are given in the following files:

```
lra/README.md

language-modeling/lmtool-fwms/README.md
```
