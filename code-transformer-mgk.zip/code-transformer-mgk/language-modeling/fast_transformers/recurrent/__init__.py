"""Implementations of transformers as recurrent functions."""
