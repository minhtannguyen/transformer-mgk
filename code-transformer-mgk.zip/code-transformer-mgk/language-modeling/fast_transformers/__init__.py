"""Provide a library with fast transformer implementations."""

__author__ = ""
__copyright__ = ""
__license__ = "MIT"
__maintainer__ = ""
__email__ = ""
__url__ = "https://github.com/idiap/fast-transformers"
__version__ = "0.4.0"
